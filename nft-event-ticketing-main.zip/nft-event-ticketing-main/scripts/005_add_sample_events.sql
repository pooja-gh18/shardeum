-- Add sample events for demonstration
-- Note: This assumes we have at least one user in the system as an organizer

INSERT INTO public.events (
  title,
  description,
  image_url,
  venue,
  event_date,
  ticket_price,
  total_tickets,
  available_tickets,
  organizer_id
) VALUES 
(
  'Web3 Conference 2024',
  'The premier blockchain and Web3 technology conference featuring industry leaders, innovative projects, and networking opportunities. Join us for two days of cutting-edge presentations on DeFi, NFTs, and the future of decentralized technology.',
  '/placeholder.svg?height=400&width=600',
  'Moscone Convention Center, San Francisco',
  '2024-06-15 10:00:00+00',
  299.99,
  500,
  485,
  (SELECT id FROM auth.users LIMIT 1)
),
(
  'NFT Art Gallery Opening',
  'Exclusive opening night for the largest digital art exhibition featuring renowned NFT artists. Experience immersive digital installations and meet the creators behind groundbreaking NFT collections.',
  '/placeholder.svg?height=400&width=600',
  'SFMOMA, San Francisco',
  '2024-05-20 19:00:00+00',
  150.00,
  200,
  167,
  (SELECT id FROM auth.users LIMIT 1)
),
(
  'Crypto Trading Masterclass',
  'Learn advanced cryptocurrency trading strategies from professional traders. This intensive workshop covers technical analysis, risk management, and portfolio optimization for both beginners and experienced traders.',
  '/placeholder.svg?height=400&width=600',
  'Financial District Conference Room, New York',
  '2024-07-10 09:00:00+00',
  199.99,
  100,
  78,
  (SELECT id FROM auth.users LIMIT 1)
);

-- Add some sample NFT tickets for demonstration
INSERT INTO public.nft_tickets (
  event_id,
  owner_id,
  token_id,
  metadata,
  blockchain_tx_hash,
  status
) VALUES 
(
  (SELECT id FROM public.events WHERE title = 'Web3 Conference 2024' LIMIT 1),
  (SELECT id FROM auth.users LIMIT 1),
  'WEB3CONF2024001',
  '{
    "name": "Web3 Conference 2024 - VIP Pass",
    "description": "Premium access to Web3 Conference 2024 including all sessions, networking events, and exclusive VIP lounge access.",
    "image": "/placeholder.svg?height=400&width=400",
    "attributes": [
      {"trait_type": "Event", "value": "Web3 Conference 2024"},
      {"trait_type": "Ticket Type", "value": "VIP"},
      {"trait_type": "Seat", "value": "A-15"},
      {"trait_type": "Access Level", "value": "Premium"}
    ]
  }',
  '0x1234567890abcdef1234567890abcdef12345678',
  'active'
);
