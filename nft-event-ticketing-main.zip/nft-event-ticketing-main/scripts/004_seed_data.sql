-- Insert sample events (these will be created after authentication is set up)
-- This script will be run after we have user authentication working

-- Sample event data structure for reference:
/*
INSERT INTO public.events (
  title,
  description,
  image_url,
  venue,
  event_date,
  ticket_price,
  total_tickets,
  available_tickets,
  organizer_id
) VALUES (
  'Web3 Conference 2024',
  'The premier blockchain and Web3 technology conference featuring industry leaders and innovative projects.',
  '/placeholder.svg?height=400&width=600',
  'Convention Center, San Francisco',
  '2024-06-15 10:00:00+00',
  299.99,
  500,
  500,
  -- organizer_id will be set when we have authenticated users
);
*/
