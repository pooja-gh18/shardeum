-- Profiles policies
CREATE POLICY "Users can view their own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- Events policies
CREATE POLICY "Anyone can view active events" ON public.events
  FOR SELECT USING (is_active = true);

CREATE POLICY "Organizers can manage their events" ON public.events
  FOR ALL USING (auth.uid() = organizer_id);

CREATE POLICY "Authenticated users can create events" ON public.events
  FOR INSERT WITH CHECK (auth.uid() = organizer_id);

-- Tickets policies
CREATE POLICY "Users can view their own tickets" ON public.tickets
  FOR SELECT USING (auth.uid() = owner_id);

CREATE POLICY "Event organizers can view tickets for their events" ON public.tickets
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.events 
      WHERE events.id = tickets.event_id 
      AND events.organizer_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert tickets they purchase" ON public.tickets
  FOR INSERT WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Users can update their own tickets" ON public.tickets
  FOR UPDATE USING (auth.uid() = owner_id);

-- Ticket transfers policies
CREATE POLICY "Users can view transfers involving their tickets" ON public.ticket_transfers
  FOR SELECT USING (
    auth.uid() = from_user_id OR 
    auth.uid() = to_user_id OR
    EXISTS (
      SELECT 1 FROM public.tickets 
      WHERE tickets.id = ticket_transfers.ticket_id 
      AND tickets.owner_id = auth.uid()
    )
  );

CREATE POLICY "Users can create transfers for their tickets" ON public.ticket_transfers
  FOR INSERT WITH CHECK (
    auth.uid() = from_user_id AND
    EXISTS (
      SELECT 1 FROM public.tickets 
      WHERE tickets.id = ticket_transfers.ticket_id 
      AND tickets.owner_id = auth.uid()
    )
  );

-- Marketplace listings policies
CREATE POLICY "Anyone can view active listings" ON public.marketplace_listings
  FOR SELECT USING (is_active = true);

CREATE POLICY "Users can manage their own listings" ON public.marketplace_listings
  FOR ALL USING (auth.uid() = seller_id);

CREATE POLICY "Users can create listings for their tickets" ON public.marketplace_listings
  FOR INSERT WITH CHECK (
    auth.uid() = seller_id AND
    EXISTS (
      SELECT 1 FROM public.tickets 
      WHERE tickets.id = marketplace_listings.ticket_id 
      AND tickets.owner_id = auth.uid()
    )
  );
