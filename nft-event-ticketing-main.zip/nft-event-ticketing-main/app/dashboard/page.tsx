import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Ticket, Plus, Calendar, Users, BarChart3, CheckCircle } from "lucide-react"

export default async function DashboardPage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  if (error || !user) {
    redirect("/auth/login")
  }

  // Get user's tickets
  const { data: tickets } = await supabase
    .from("tickets")
    .select(`
      *,
      events (
        title,
        event_date,
        venue
      )
    `)
    .eq("owner_id", user.id)
    .order("created_at", { ascending: false })

  // Get user's events (if they're an organizer)
  const { data: organizedEvents } = await supabase
    .from("events")
    .select("*")
    .eq("organizer_id", user.id)
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
              <Ticket className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              NFT Tickets
            </span>
          </Link>
          <div className="flex items-center space-x-4">
            <Link href="/events">
              <Button variant="ghost">Browse Events</Button>
            </Link>
            <Link href="/marketplace">
              <Button variant="ghost">Marketplace</Button>
            </Link>
            <form action="/auth/signout" method="post">
              <Button variant="ghost" type="submit">
                Sign Out
              </Button>
            </form>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Welcome to Your Dashboard
          </h1>
          <p className="text-gray-600 dark:text-gray-300">Manage your NFT tickets and events</p>
        </div>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">My Tickets</p>
                  <p className="text-2xl font-bold">{tickets?.length || 0}</p>
                </div>
                <Ticket className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Events Created</p>
                  <p className="text-2xl font-bold">{organizedEvents?.length || 0}</p>
                </div>
                <Calendar className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Value</p>
                  <p className="text-2xl font-bold">
                    ${tickets?.reduce((sum, ticket) => sum + (ticket.purchase_price || 0), 0).toFixed(2) || "0.00"}
                  </p>
                </div>
                <Users className="w-8 h-8 text-indigo-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>Get started with common tasks</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Link href="/events">
                <Button className="w-full justify-start bg-transparent" variant="outline">
                  <Ticket className="w-4 h-4 mr-2" />
                  Browse Events
                </Button>
              </Link>
              <Link href="/dashboard/create-event">
                <Button className="w-full justify-start bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Create Event
                </Button>
              </Link>
              <Link href="/dashboard/tickets">
                <Button className="w-full justify-start bg-transparent" variant="outline">
                  <Users className="w-4 h-4 mr-2" />
                  My Tickets
                </Button>
              </Link>
              <Link href="/verify">
                <Button className="w-full justify-start bg-transparent" variant="outline">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Verify Tickets
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Your latest ticket purchases and events</CardDescription>
            </CardHeader>
            <CardContent>
              {tickets && tickets.length > 0 ? (
                <div className="space-y-3">
                  {tickets.slice(0, 3).map((ticket: any) => (
                    <div
                      key={ticket.id}
                      className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg"
                    >
                      <div>
                        <p className="font-medium text-sm">{ticket.events?.title}</p>
                        <p className="text-xs text-gray-600 dark:text-gray-400">Ticket #{ticket.ticket_number}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">${ticket.purchase_price}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-600 dark:text-gray-400 text-center py-4">
                  No tickets yet. Start by browsing events!
                </p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Organized Events */}
        {organizedEvents && organizedEvents.length > 0 && (
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="w-5 h-5 mr-2" />
                Your Events
              </CardTitle>
              <CardDescription>Events you've created and their performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {organizedEvents.map((event: any) => (
                  <div
                    key={event.id}
                    className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  >
                    <h4 className="font-medium mb-2">{event.title}</h4>
                    <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                      <p>📍 {event.venue}</p>
                      <p>
                        🎫 {event.total_tickets - event.available_tickets} / {event.total_tickets} sold
                      </p>
                      <p>💰 ${event.ticket_price} per ticket</p>
                    </div>
                    <div className="mt-3 flex space-x-2">
                      <Link href={`/dashboard/event-analytics/${event.id}`}>
                        <Button size="sm" variant="outline" className="text-xs bg-transparent">
                          Analytics
                        </Button>
                      </Link>
                      <Link href={`/events/${event.id}`}>
                        <Button size="sm" variant="outline" className="text-xs bg-transparent">
                          View
                        </Button>
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
