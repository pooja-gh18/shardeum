import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft, Users, CheckCircle, Clock, DollarSign, TrendingUp } from "lucide-react"
import { format } from "date-fns"

export default async function EventAnalyticsPage({ params }: { params: { eventId: string } }) {
  const supabase = await createClient()

  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser()
  if (authError || !user) {
    redirect("/auth/login")
  }

  // Get event details
  const { data: event, error: eventError } = await supabase
    .from("events")
    .select("*")
    .eq("id", params.eventId)
    .eq("organizer_id", user.id)
    .single()

  if (eventError || !event) {
    redirect("/dashboard")
  }

  // Get ticket statistics
  const { data: tickets } = await supabase
    .from("tickets")
    .select(`
      *,
      profiles:owner_id (
        full_name,
        email
      )
    `)
    .eq("event_id", params.eventId)
    .order("created_at", { ascending: false })

  const totalSold = tickets?.length || 0
  const totalUsed = tickets?.filter((t) => t.is_used).length || 0
  const totalRevenue = tickets?.reduce((sum, ticket) => sum + (ticket.purchase_price || 0), 0) || 0
  const attendanceRate = totalSold > 0 ? (totalUsed / totalSold) * 100 : 0

  // Get marketplace activity
  const { data: marketplaceActivity } = await supabase
    .from("marketplace_listings")
    .select(`
      *,
      tickets (
        ticket_number,
        purchase_price
      )
    `)
    .in("ticket_id", tickets?.map((t) => t.id) || [])
    .order("created_at", { ascending: false })

  const activeListings = marketplaceActivity?.filter((listing) => listing.is_active).length || 0
  const averageResalePrice =
    marketplaceActivity && marketplaceActivity.length > 0
      ? marketplaceActivity.reduce((sum, listing) => sum + Number(listing.price), 0) / marketplaceActivity.length
      : 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              Event Analytics
            </span>
          </Link>
          <Link href="/dashboard">
            <Button variant="ghost" className="flex items-center space-x-2">
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Dashboard</span>
            </Button>
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Event Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">{event.title}</h1>
          <p className="text-gray-600 dark:text-gray-300 mb-4">{event.description}</p>
          <div className="flex flex-wrap gap-4 text-sm text-gray-600 dark:text-gray-400">
            <span>📍 {event.venue}</span>
            <span>📅 {format(new Date(event.event_date), "PPP p")}</span>
            <Badge variant={event.is_active ? "default" : "secondary"}>{event.is_active ? "Active" : "Inactive"}</Badge>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Tickets Sold</p>
                  <p className="text-2xl font-bold">{totalSold}</p>
                  <p className="text-xs text-gray-500">of {event.total_tickets}</p>
                </div>
                <Users className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Checked In</p>
                  <p className="text-2xl font-bold">{totalUsed}</p>
                  <p className="text-xs text-gray-500">{attendanceRate.toFixed(1)}% rate</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Revenue</p>
                  <p className="text-2xl font-bold">${totalRevenue.toFixed(2)}</p>
                  <p className="text-xs text-gray-500">Total earned</p>
                </div>
                <DollarSign className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Resale Activity</p>
                  <p className="text-2xl font-bold">{activeListings}</p>
                  <p className="text-xs text-gray-500">Active listings</p>
                </div>
                <TrendingUp className="w-8 h-8 text-indigo-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Recent Ticket Sales */}
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardHeader>
              <CardTitle>Recent Ticket Sales</CardTitle>
              <CardDescription>Latest NFT ticket purchases</CardDescription>
            </CardHeader>
            <CardContent>
              {tickets && tickets.length > 0 ? (
                <div className="space-y-3">
                  {tickets.slice(0, 5).map((ticket: any) => (
                    <div
                      key={ticket.id}
                      className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center text-white text-sm font-bold">
                          #{ticket.ticket_number}
                        </div>
                        <div>
                          <p className="font-medium text-sm">{ticket.profiles?.full_name}</p>
                          <p className="text-xs text-gray-600 dark:text-gray-400">
                            {format(new Date(ticket.created_at), "MMM d, yyyy")}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">${ticket.purchase_price}</p>
                        {ticket.is_used && <Badge className="bg-green-100 text-green-800 text-xs">Used</Badge>}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-600 dark:text-gray-400 text-center py-4">No tickets sold yet</p>
              )}
            </CardContent>
          </Card>

          {/* Marketplace Activity */}
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardHeader>
              <CardTitle>Marketplace Activity</CardTitle>
              <CardDescription>Secondary market for your event tickets</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <p className="text-2xl font-bold text-purple-600">{activeListings}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Active Listings</p>
                  </div>
                  <div className="text-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <p className="text-2xl font-bold text-blue-600">${averageResalePrice.toFixed(2)}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Avg. Resale Price</p>
                  </div>
                </div>

                {marketplaceActivity && marketplaceActivity.length > 0 ? (
                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">Recent Listings</h4>
                    {marketplaceActivity.slice(0, 3).map((listing: any) => (
                      <div
                        key={listing.id}
                        className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded"
                      >
                        <span className="text-sm">Ticket #{listing.tickets?.ticket_number}</span>
                        <div className="text-right">
                          <p className="text-sm font-medium">${listing.price}</p>
                          <Badge variant={listing.is_active ? "default" : "secondary"} className="text-xs">
                            {listing.is_active ? "Active" : "Sold"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-600 dark:text-gray-400 text-center py-4 text-sm">
                    No marketplace activity yet
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mt-8">
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>Manage your event</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4">
                <Link href="/verify">
                  <Button className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Verify Tickets
                  </Button>
                </Link>
                <Link href={`/events/${event.id}`}>
                  <Button variant="outline">
                    <Clock className="w-4 h-4 mr-2" />
                    View Event Page
                  </Button>
                </Link>
                <Link href="/marketplace">
                  <Button variant="outline">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    View Marketplace
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
