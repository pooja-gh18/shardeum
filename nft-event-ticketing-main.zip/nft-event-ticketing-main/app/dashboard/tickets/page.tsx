import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft, Ticket, Calendar } from "lucide-react"
import NFTTicketCard from "@/components/nft-ticket-card"

export default async function TicketsPage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  if (error || !user) {
    redirect("/auth/login")
  }

  // Get user's tickets with event details
  const { data: tickets } = await supabase
    .from("tickets")
    .select(`
      *,
      events (
        id,
        title,
        description,
        venue,
        event_date,
        image_url,
        organizer_id,
        profiles:organizer_id (
          full_name
        )
      )
    `)
    .eq("owner_id", user.id)
    .order("created_at", { ascending: false })

  const activeTickets = tickets?.filter((ticket) => !ticket.is_used) || []
  const usedTickets = tickets?.filter((ticket) => ticket.is_used) || []

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
              <Ticket className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              NFT Tickets
            </span>
          </Link>
          <Link href="/dashboard">
            <Button variant="ghost" className="flex items-center space-x-2">
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Dashboard</span>
            </Button>
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            My NFT Tickets
          </h1>
          <p className="text-gray-600 dark:text-gray-300">Your collection of event NFT tickets and digital memories</p>
        </div>

        {tickets && tickets.length > 0 ? (
          <div className="space-y-8">
            {/* Active Tickets */}
            {activeTickets.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold mb-6 flex items-center">
                  <Ticket className="w-6 h-6 mr-2 text-purple-600" />
                  Active Tickets ({activeTickets.length})
                </h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {activeTickets.map((ticket: any) => (
                    <NFTTicketCard key={ticket.id} ticket={ticket} />
                  ))}
                </div>
              </div>
            )}

            {/* Used Tickets */}
            {usedTickets.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold mb-6 flex items-center">
                  <Calendar className="w-6 h-6 mr-2 text-gray-600" />
                  Event Memories ({usedTickets.length})
                </h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {usedTickets.map((ticket: any) => (
                    <NFTTicketCard key={ticket.id} ticket={ticket} />
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="w-24 h-24 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Ticket className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-2xl font-bold mb-4">No Tickets Yet</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto">
              Start building your NFT ticket collection by purchasing tickets to amazing events!
            </p>
            <Link href="/events">
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                Browse Events
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}
