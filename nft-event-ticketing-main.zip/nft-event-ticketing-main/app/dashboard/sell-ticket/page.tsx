"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import { ArrowLeft, Ticket, DollarSign } from "lucide-react"
import { format } from "date-fns"

interface UserTicket {
  id: string
  token_id: number
  ticket_number: number
  purchase_price: number
  is_used: boolean
  events: {
    id: string
    title: string
    venue: string
    event_date: string
  }
}

export default function SellTicketPage() {
  const [tickets, setTickets] = useState<UserTicket[]>([])
  const [selectedTicketId, setSelectedTicketId] = useState("")
  const [price, setPrice] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const searchParams = useSearchParams()
  const preselectedTicketId = searchParams.get("ticketId")

  useEffect(() => {
    fetchUserTickets()
  }, [])

  useEffect(() => {
    if (preselectedTicketId && tickets.length > 0) {
      setSelectedTicketId(preselectedTicketId)
      const selectedTicket = tickets.find((t) => t.id === preselectedTicketId)
      if (selectedTicket) {
        setPrice(selectedTicket.purchase_price.toString())
      }
    }
  }, [preselectedTicketId, tickets])

  const fetchUserTickets = async () => {
    const supabase = createClient()

    try {
      const {
        data: { user },
        error: authError,
      } = await supabase.auth.getUser()

      if (authError || !user) {
        router.push("/auth/login")
        return
      }

      const { data, error } = await supabase
        .from("tickets")
        .select(`
          id,
          token_id,
          ticket_number,
          purchase_price,
          is_used,
          events (
            id,
            title,
            venue,
            event_date
          )
        `)
        .eq("owner_id", user.id)
        .eq("is_used", false)
        .eq("is_transferred", false)

      if (error) {
        throw error
      }

      // Filter out tickets that are already listed
      const { data: existingListings } = await supabase
        .from("marketplace_listings")
        .select("ticket_id")
        .eq("is_active", true)

      const listedTicketIds = existingListings?.map((listing) => listing.ticket_id) || []
      const availableTickets = data?.filter((ticket) => !listedTicketIds.includes(ticket.id)) || []

      setTickets(availableTickets)
    } catch (error: any) {
      console.error("Error fetching tickets:", error)
      setError(error.message)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const supabase = createClient()
    setIsLoading(true)
    setError(null)

    try {
      const {
        data: { user },
        error: authError,
      } = await supabase.auth.getUser()

      if (authError || !user) {
        router.push("/auth/login")
        return
      }

      const { error: insertError } = await supabase.from("marketplace_listings").insert({
        ticket_id: selectedTicketId,
        seller_id: user.id,
        price: Number.parseFloat(price),
      })

      if (insertError) {
        throw insertError
      }

      router.push("/marketplace")
    } catch (error: any) {
      console.error("List ticket error:", error)
      setError(error.message || "Failed to list ticket")
    } finally {
      setIsLoading(false)
    }
  }

  const selectedTicket = tickets.find((t) => t.id === selectedTicketId)

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
              <Ticket className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              NFT Tickets
            </span>
          </Link>
          <Link href="/dashboard/tickets">
            <Button variant="ghost" className="flex items-center space-x-2">
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Tickets</span>
            </Button>
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardHeader>
              <CardTitle className="text-2xl bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent flex items-center">
                <DollarSign className="w-6 h-6 mr-2 text-purple-600" />
                List Ticket for Sale
              </CardTitle>
              <CardDescription>Set your price and list your NFT ticket on the marketplace</CardDescription>
            </CardHeader>
            <CardContent>
              {tickets.length === 0 ? (
                <div className="text-center py-8">
                  <Ticket className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No Available Tickets</h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    You don't have any tickets available for sale.
                  </p>
                  <Link href="/events">
                    <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                      Browse Events
                    </Button>
                  </Link>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="ticket">Select Ticket *</Label>
                    <Select value={selectedTicketId} onValueChange={setSelectedTicketId} required>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a ticket to sell" />
                      </SelectTrigger>
                      <SelectContent>
                        {tickets.map((ticket) => (
                          <SelectItem key={ticket.id} value={ticket.id}>
                            #{ticket.ticket_number} - {ticket.events.title} (${ticket.purchase_price})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedTicket && (
                    <Card className="bg-gray-50 dark:bg-gray-800 border-0">
                      <CardContent className="p-4">
                        <h4 className="font-semibold mb-2">Ticket Details</h4>
                        <div className="space-y-1 text-sm">
                          <p>
                            <span className="text-gray-600 dark:text-gray-400">Event:</span>{" "}
                            {selectedTicket.events.title}
                          </p>
                          <p>
                            <span className="text-gray-600 dark:text-gray-400">Venue:</span>{" "}
                            {selectedTicket.events.venue}
                          </p>
                          <p>
                            <span className="text-gray-600 dark:text-gray-400">Date:</span>{" "}
                            {format(new Date(selectedTicket.events.event_date), "PPP")}
                          </p>
                          <p>
                            <span className="text-gray-600 dark:text-gray-400">Original Price:</span> $
                            {selectedTicket.purchase_price}
                          </p>
                          <p>
                            <span className="text-gray-600 dark:text-gray-400">Token ID:</span>{" "}
                            {selectedTicket.token_id}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="price">Sale Price (USD) *</Label>
                    <Input
                      id="price"
                      type="number"
                      step="0.01"
                      min="0.01"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      placeholder="Enter your asking price"
                      required
                    />
                    {selectedTicket && price && (
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {Number.parseFloat(price) > selectedTicket.purchase_price ? (
                          <span className="text-green-600">
                            +
                            {(
                              ((Number.parseFloat(price) - selectedTicket.purchase_price) /
                                selectedTicket.purchase_price) *
                              100
                            ).toFixed(1)}
                            % above original price
                          </span>
                        ) : Number.parseFloat(price) < selectedTicket.purchase_price ? (
                          <span className="text-red-600">
                            {(
                              ((Number.parseFloat(price) - selectedTicket.purchase_price) /
                                selectedTicket.purchase_price) *
                              100
                            ).toFixed(1)}
                            % below original price
                          </span>
                        ) : (
                          <span className="text-gray-600">Same as original price</span>
                        )}
                      </p>
                    )}
                  </div>

                  {error && (
                    <div className="p-3 text-sm text-red-600 bg-red-50 dark:bg-red-900/20 dark:text-red-400 rounded-lg">
                      {error}
                    </div>
                  )}

                  <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                    <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">Important Notes:</h4>
                    <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
                      <li>• Once listed, your ticket will be available for purchase immediately</li>
                      <li>• You can cancel the listing anytime before it's sold</li>
                      <li>• The ticket will be transferred to the buyer upon purchase</li>
                      <li>• All transactions are recorded on the blockchain</li>
                    </ul>
                  </div>

                  <Button
                    type="submit"
                    className="w-full h-12 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                    disabled={isLoading || !selectedTicketId || !price}
                  >
                    {isLoading ? "Listing Ticket..." : "List for Sale"}
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
