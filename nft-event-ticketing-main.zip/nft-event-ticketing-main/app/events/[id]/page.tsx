import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Calendar, MapPin, Ticket, Users, ArrowLeft } from "lucide-react"
import { format } from "date-fns"
import { notFound } from "next/navigation"
import PurchaseTicketButton from "@/components/purchase-ticket-button"

interface Event {
  id: string
  title: string
  description: string
  image_url: string
  venue: string
  event_date: string
  ticket_price: number
  total_tickets: number
  available_tickets: number
  organizer_id: string
  profiles: {
    full_name: string
  }
}

export default async function EventDetailPage({ params }: { params: { id: string } }) {
  const supabase = await createClient()

  const { data: event, error } = await supabase
    .from("events")
    .select(`
      *,
      profiles:organizer_id (
        full_name
      )
    `)
    .eq("id", params.id)
    .eq("is_active", true)
    .single()

  if (error || !event) {
    notFound()
  }

  const eventDate = new Date(event.event_date)
  const isEventPassed = eventDate < new Date()
  const soldOut = event.available_tickets <= 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
              <Ticket className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              NFT Tickets
            </span>
          </Link>
          <div className="flex items-center space-x-4">
            <Link href="/events">
              <Button variant="ghost" className="flex items-center space-x-2">
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Events</span>
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Event Image */}
          <div className="relative mb-8 rounded-2xl overflow-hidden shadow-2xl">
            <img
              src={
                event.image_url ||
                `/placeholder.svg?height=400&width=800&query=event+${encodeURIComponent(event.title)}`
              }
              alt={event.title}
              className="w-full h-64 md:h-96 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
            <div className="absolute bottom-6 left-6 right-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">{event.title}</h1>
                  <p className="text-white/90 text-lg">Organized by {event.profiles?.full_name || "Unknown"}</p>
                </div>
                <Badge className="bg-white/90 text-gray-900 text-lg px-4 py-2">${event.ticket_price}</Badge>
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Event Details */}
            <div className="lg:col-span-2 space-y-6">
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
                <CardHeader>
                  <CardTitle className="text-2xl">About This Event</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 dark:text-gray-300 leading-relaxed">{event.description}</p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
                <CardHeader>
                  <CardTitle className="text-xl">Event Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center text-gray-700 dark:text-gray-300">
                    <Calendar className="w-5 h-5 mr-3 text-purple-600" />
                    <div>
                      <p className="font-medium">{format(eventDate, "PPPP")}</p>
                      <p className="text-sm text-gray-500">{format(eventDate, "p")}</p>
                    </div>
                  </div>

                  <div className="flex items-center text-gray-700 dark:text-gray-300">
                    <MapPin className="w-5 h-5 mr-3 text-purple-600" />
                    <p>{event.venue}</p>
                  </div>

                  <div className="flex items-center text-gray-700 dark:text-gray-300">
                    <Users className="w-5 h-5 mr-3 text-purple-600" />
                    <p>
                      {event.available_tickets} of {event.total_tickets} tickets available
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Purchase Card */}
            <div className="lg:col-span-1">
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80 sticky top-24">
                <CardHeader>
                  <CardTitle className="text-xl">Get Your NFT Ticket</CardTitle>
                  <CardDescription>Secure your spot and own a unique digital collectible</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-600 mb-2">${event.ticket_price}</div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">per NFT ticket</p>
                  </div>

                  {isEventPassed ? (
                    <Button disabled className="w-full h-12">
                      Event Has Passed
                    </Button>
                  ) : soldOut ? (
                    <Button disabled className="w-full h-12">
                      Sold Out
                    </Button>
                  ) : (
                    <PurchaseTicketButton
                      eventId={event.id}
                      price={event.ticket_price}
                      availableTickets={event.available_tickets}
                    />
                  )}

                  <div className="text-xs text-gray-500 dark:text-gray-400 text-center">
                    <p>✓ Blockchain verified authenticity</p>
                    <p>✓ Transferable and tradeable</p>
                    <p>✓ Permanent digital collectible</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
