"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, MapPin, Users, Ticket, ShoppingCart, Wallet, QrCode, TrendingUp } from "lucide-react"

export default function DemoPage() {
  const [currentStep, setCurrentStep] = useState(1)

  const steps = [
    { id: 1, title: "Browse Events", description: "Discover amazing events" },
    { id: 2, title: "Select Event", description: "Choose your event" },
    { id: 3, title: "Purchase Ticket", description: "Buy NFT ticket" },
    { id: 4, title: "View NFT Ticket", description: "Access your digital ticket" },
    { id: 5, title: "Event Check-in", description: "Verify at venue" },
    { id: 6, title: "Marketplace", description: "Trade tickets" },
  ]

  const sampleEvent = {
    id: 1,
    title: "Web3 Conference 2024",
    description:
      "The premier blockchain and Web3 technology conference featuring industry leaders, innovative projects, and networking opportunities.",
    image: "/modern-tech-conference-with-blockchain-theme.jpg",
    venue: "Moscone Convention Center, San Francisco",
    date: "June 15, 2024",
    time: "10:00 AM",
    price: 299.99,
    available: 485,
    total: 500,
  }

  const sampleNFT = {
    tokenId: "WEB3CONF2024001",
    name: "Web3 Conference 2024 - VIP Pass",
    image: "/vip-conference-pass-nft-design.jpg",
    attributes: [
      { trait_type: "Event", value: "Web3 Conference 2024" },
      { trait_type: "Ticket Type", value: "VIP" },
      { trait_type: "Seat", value: "A-15" },
      { trait_type: "Access Level", value: "Premium" },
    ],
    txHash: "0x1234567890abcdef1234567890abcdef12345678",
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-4">NFT Ticketing System Demo</h1>
          <p className="text-xl text-gray-300 mb-8">Complete End-to-End User Journey</p>

          {/* Step Navigation */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {steps.map((step) => (
              <Button
                key={step.id}
                variant={currentStep === step.id ? "default" : "outline"}
                size="sm"
                onClick={() => setCurrentStep(step.id)}
                className={currentStep === step.id ? "bg-purple-600 hover:bg-purple-700" : ""}
              >
                {step.id}. {step.title}
              </Button>
            ))}
          </div>
        </div>

        {/* Step Content */}
        <div className="max-w-4xl mx-auto">
          {currentStep === 1 && (
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Step 1: Browse Events
                </CardTitle>
                <CardDescription className="text-gray-300">
                  Users visit /events to discover upcoming events
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4">
                  <Card className="bg-white/5 border-white/10">
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        <img
                          src={sampleEvent.image || "/placeholder.svg"}
                          alt={sampleEvent.title}
                          className="w-24 h-24 rounded-lg object-cover"
                        />
                        <div className="flex-1">
                          <h3 className="text-white font-semibold">{sampleEvent.title}</h3>
                          <p className="text-gray-300 text-sm mb-2">{sampleEvent.description.slice(0, 100)}...</p>
                          <div className="flex items-center gap-4 text-sm text-gray-400">
                            <span className="flex items-center gap-1">
                              <MapPin className="h-4 w-4" />
                              {sampleEvent.venue}
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar className="h-4 w-4" />
                              {sampleEvent.date}
                            </span>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-purple-400">${sampleEvent.price}</p>
                          <p className="text-sm text-gray-400">{sampleEvent.available} available</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                <Button onClick={() => setCurrentStep(2)} className="w-full bg-purple-600 hover:bg-purple-700">
                  Select This Event →
                </Button>
              </CardContent>
            </Card>
          )}

          {currentStep === 2 && (
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Ticket className="h-5 w-5" />
                  Step 2: Event Details & Selection
                </CardTitle>
                <CardDescription className="text-gray-300">
                  Users view detailed event information at /events/[id]
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <img
                      src={sampleEvent.image || "/placeholder.svg"}
                      alt={sampleEvent.title}
                      className="w-full h-64 rounded-lg object-cover"
                    />
                  </div>
                  <div className="space-y-4">
                    <h2 className="text-2xl font-bold text-white">{sampleEvent.title}</h2>
                    <p className="text-gray-300">{sampleEvent.description}</p>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-gray-300">
                        <MapPin className="h-4 w-4" />
                        {sampleEvent.venue}
                      </div>
                      <div className="flex items-center gap-2 text-gray-300">
                        <Calendar className="h-4 w-4" />
                        {sampleEvent.date} at {sampleEvent.time}
                      </div>
                      <div className="flex items-center gap-2 text-gray-300">
                        <Users className="h-4 w-4" />
                        {sampleEvent.available} of {sampleEvent.total} tickets available
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-3xl font-bold text-purple-400">${sampleEvent.price}</span>
                      <Badge variant="secondary" className="bg-green-600/20 text-green-400">
                        Available
                      </Badge>
                    </div>
                  </div>
                </div>
                <Button onClick={() => setCurrentStep(3)} className="w-full bg-purple-600 hover:bg-purple-700">
                  Purchase NFT Ticket →
                </Button>
              </CardContent>
            </Card>
          )}

          {currentStep === 3 && (
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5" />
                  Step 3: Purchase NFT Ticket
                </CardTitle>
                <CardDescription className="text-gray-300">
                  Secure blockchain-based ticket purchase process
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-white/5 rounded-lg p-6 border border-white/10">
                  <h3 className="text-white font-semibold mb-4">Purchase Summary</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between text-gray-300">
                      <span>Event:</span>
                      <span className="text-white">{sampleEvent.title}</span>
                    </div>
                    <div className="flex justify-between text-gray-300">
                      <span>Date:</span>
                      <span className="text-white">{sampleEvent.date}</span>
                    </div>
                    <div className="flex justify-between text-gray-300">
                      <span>Ticket Type:</span>
                      <span className="text-white">VIP Pass</span>
                    </div>
                    <div className="flex justify-between text-gray-300">
                      <span>NFT Minting Fee:</span>
                      <span className="text-white">$5.00</span>
                    </div>
                    <hr className="border-white/20" />
                    <div className="flex justify-between text-lg font-semibold">
                      <span className="text-white">Total:</span>
                      <span className="text-purple-400">${(sampleEvent.price + 5).toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-600/20 border border-blue-500/30 rounded-lg p-4">
                  <p className="text-blue-300 text-sm">
                    🔒 Your ticket will be minted as a unique NFT on the blockchain, ensuring authenticity and
                    preventing fraud.
                  </p>
                </div>

                <Button onClick={() => setCurrentStep(4)} className="w-full bg-purple-600 hover:bg-purple-700">
                  Complete Purchase & Mint NFT →
                </Button>
              </CardContent>
            </Card>
          )}

          {currentStep === 4 && (
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Wallet className="h-5 w-5" />
                  Step 4: Your NFT Ticket
                </CardTitle>
                <CardDescription className="text-gray-300">
                  Access your digital ticket at /dashboard/tickets
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <img
                      src={sampleNFT.image || "/placeholder.svg"}
                      alt={sampleNFT.name}
                      className="w-full h-64 rounded-lg object-cover border-2 border-purple-500/30"
                    />
                    <div className="text-center">
                      <Badge className="bg-green-600/20 text-green-400">Active Ticket</Badge>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-xl font-bold text-white">{sampleNFT.name}</h3>
                    <div className="space-y-2">
                      <p className="text-gray-300">
                        <strong>Token ID:</strong> {sampleNFT.tokenId}
                      </p>
                      <p className="text-gray-300">
                        <strong>Blockchain TX:</strong>
                        <span className="text-blue-400 font-mono text-sm block">{sampleNFT.txHash}</span>
                      </p>
                    </div>

                    <div className="space-y-2">
                      <h4 className="text-white font-semibold">NFT Attributes:</h4>
                      {sampleNFT.attributes.map((attr, index) => (
                        <div key={index} className="flex justify-between text-sm">
                          <span className="text-gray-400">{attr.trait_type}:</span>
                          <span className="text-white">{attr.value}</span>
                        </div>
                      ))}
                    </div>

                    <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                      <div className="flex items-center justify-center">
                        <QrCode className="h-16 w-16 text-purple-400" />
                      </div>
                      <p className="text-center text-sm text-gray-300 mt-2">QR Code for event check-in</p>
                    </div>
                  </div>
                </div>
                <Button onClick={() => setCurrentStep(5)} className="w-full bg-purple-600 hover:bg-purple-700">
                  Proceed to Event Check-in →
                </Button>
              </CardContent>
            </Card>
          )}

          {currentStep === 5 && (
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <QrCode className="h-5 w-5" />
                  Step 5: Event Check-in & Verification
                </CardTitle>
                <CardDescription className="text-gray-300">Organizers verify tickets at /verify</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-white/5 rounded-lg p-6 border border-white/10">
                    <h3 className="text-white font-semibold mb-4">Attendee Experience</h3>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                        <span className="text-gray-300">Present QR code at venue</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                        <span className="text-gray-300">Organizer scans ticket</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                        <span className="text-gray-300">Blockchain verification</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                        <span className="text-gray-300">Entry granted</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 rounded-lg p-6 border border-white/10">
                    <h3 className="text-white font-semibold mb-4">Organizer Dashboard</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-300">Total Tickets:</span>
                        <span className="text-white">500</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Checked In:</span>
                        <span className="text-green-400">347</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Revenue:</span>
                        <span className="text-purple-400">$149,965</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Fraud Attempts:</span>
                        <span className="text-red-400">0</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-green-600/20 border border-green-500/30 rounded-lg p-4">
                  <p className="text-green-300 text-sm">
                    ✅ Ticket verified successfully! NFT ownership confirmed on blockchain.
                  </p>
                </div>

                <Button onClick={() => setCurrentStep(6)} className="w-full bg-purple-600 hover:bg-purple-700">
                  Explore Marketplace →
                </Button>
              </CardContent>
            </Card>
          )}

          {currentStep === 6 && (
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Step 6: Secondary Marketplace
                </CardTitle>
                <CardDescription className="text-gray-300">Trade tickets safely at /marketplace</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4">
                  <Card className="bg-white/5 border-white/10">
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        <img
                          src="/nft-ticket-marketplace-listing.jpg"
                          alt="Marketplace listing"
                          className="w-20 h-20 rounded-lg object-cover"
                        />
                        <div className="flex-1">
                          <h3 className="text-white font-semibold">Web3 Conference 2024 - VIP</h3>
                          <p className="text-gray-300 text-sm">Seat A-12 • Premium Access</p>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge className="bg-blue-600/20 text-blue-400">For Sale</Badge>
                            <span className="text-sm text-gray-400">Listed 2 hours ago</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-purple-400">$350.00</p>
                          <p className="text-sm text-gray-400 line-through">$299.99</p>
                          <p className="text-xs text-green-400">+16.7%</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-white/5 border-white/10">
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        <img
                          src="/nft-art-gallery-ticket.jpg"
                          alt="Art gallery ticket"
                          className="w-20 h-20 rounded-lg object-cover"
                        />
                        <div className="flex-1">
                          <h3 className="text-white font-semibold">NFT Art Gallery Opening</h3>
                          <p className="text-gray-300 text-sm">General Admission</p>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge className="bg-orange-600/20 text-orange-400">Hot</Badge>
                            <span className="text-sm text-gray-400">3 bids</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-purple-400">$180.00</p>
                          <p className="text-sm text-gray-400 line-through">$150.00</p>
                          <p className="text-xs text-green-400">+20%</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="bg-white/5 rounded-lg p-6 border border-white/10">
                  <h3 className="text-white font-semibold mb-4">Marketplace Features</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <h4 className="text-purple-400 font-medium">For Buyers:</h4>
                      <ul className="text-sm text-gray-300 space-y-1">
                        <li>• Browse verified NFT tickets</li>
                        <li>• Price history tracking</li>
                        <li>• Secure blockchain transfers</li>
                        <li>• Instant ownership verification</li>
                      </ul>
                    </div>
                    <div className="space-y-2">
                      <h4 className="text-purple-400 font-medium">For Sellers:</h4>
                      <ul className="text-sm text-gray-300 space-y-1">
                        <li>• List tickets at market price</li>
                        <li>• Automatic royalty payments</li>
                        <li>• Fraud protection</li>
                        <li>• Real-time price updates</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <Button onClick={() => setCurrentStep(1)} className="w-full bg-purple-600 hover:bg-purple-700">
                  Start Over - Browse More Events
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Navigation */}
        <div className="flex justify-center gap-4 mt-8">
          <Button
            variant="outline"
            onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
            disabled={currentStep === 1}
          >
            Previous
          </Button>
          <Button
            onClick={() => setCurrentStep(Math.min(6, currentStep + 1))}
            disabled={currentStep === 6}
            className="bg-purple-600 hover:bg-purple-700"
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  )
}
