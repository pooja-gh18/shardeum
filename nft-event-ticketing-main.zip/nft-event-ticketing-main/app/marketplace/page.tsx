import { createClient } from "@/lib/supabase/server"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Ticket, TrendingUp, User } from "lucide-react"
import MarketplaceTicketCard from "@/components/marketplace-ticket-card"

export default async function MarketplacePage() {
  const supabase = await createClient()

  // Get active marketplace listings with ticket and event details
  const { data: listings, error } = await supabase
    .from("marketplace_listings")
    .select(`
      *,
      tickets (
        id,
        token_id,
        ticket_number,
        purchase_price,
        nft_metadata,
        events (
          id,
          title,
          description,
          venue,
          event_date,
          image_url,
          profiles:organizer_id (
            full_name
          )
        )
      ),
      profiles:seller_id (
        full_name
      )
    `)
    .eq("is_active", true)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching marketplace listings:", error)
  }

  // Get marketplace stats
  const { data: stats } = await supabase.from("marketplace_listings").select("price").eq("is_active", true)

  const totalListings = listings?.length || 0
  const averagePrice =
    stats && stats.length > 0 ? stats.reduce((sum, listing) => sum + Number(listing.price), 0) / stats.length : 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
              <Ticket className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              NFT Tickets
            </span>
          </Link>
          <div className="flex items-center space-x-4">
            <Link href="/events">
              <Button variant="ghost">Events</Button>
            </Link>
            <Link href="/dashboard">
              <Button variant="ghost">Dashboard</Button>
            </Link>
            <Link href="/auth/login">
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                Sign In
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            NFT Ticket Marketplace
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Buy and sell authentic NFT event tickets from verified users
          </p>
        </div>

        {/* Marketplace Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Active Listings</p>
                  <p className="text-2xl font-bold">{totalListings}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Average Price</p>
                  <p className="text-2xl font-bold">${averagePrice.toFixed(2)}</p>
                </div>
                <Ticket className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Volume</p>
                  <p className="text-2xl font-bold">${(totalListings * averagePrice).toFixed(2)}</p>
                </div>
                <User className="w-8 h-8 text-indigo-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Marketplace Listings */}
        {listings && listings.length > 0 ? (
          <div>
            <h2 className="text-2xl font-bold mb-6">Available Tickets</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {listings.map((listing: any) => (
                <MarketplaceTicketCard key={listing.id} listing={listing} />
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="w-24 h-24 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Ticket className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-2xl font-bold mb-4">No Listings Yet</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-8">Be the first to list your NFT tickets for sale!</p>
            <Link href="/dashboard/tickets">
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                List Your Tickets
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}
