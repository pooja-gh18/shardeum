"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Ticket, Search, CheckCircle, XCircle, Calendar, MapPin, User, Hash } from "lucide-react"
import { format } from "date-fns"

interface TicketVerification {
  id: string
  token_id: number
  ticket_number: number
  is_used: boolean
  used_at: string | null
  owner_id: string
  events: {
    id: string
    title: string
    venue: string
    event_date: string
    organizer_id: string
  }
  profiles: {
    full_name: string
    email: string
  }
}

export default function VerifyPage() {
  const [ticketNumber, setTicketNumber] = useState("")
  const [tokenId, setTokenId] = useState("")
  const [searchResult, setSearchResult] = useState<TicketVerification | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    checkUser()
  }, [])

  const checkUser = async () => {
    const supabase = createClient()
    const {
      data: { user },
      error,
    } = await supabase.auth.getUser()

    if (error || !user) {
      window.location.href = "/auth/login"
      return
    }

    setUser(user)
  }

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!ticketNumber && !tokenId) return

    const supabase = createClient()
    setIsLoading(true)
    setError(null)
    setSearchResult(null)

    try {
      let query = supabase.from("tickets").select(`
          *,
          events (
            id,
            title,
            venue,
            event_date,
            organizer_id
          ),
          profiles:owner_id (
            full_name,
            email
          )
        `)

      if (ticketNumber) {
        query = query.eq("ticket_number", Number.parseInt(ticketNumber))
      } else if (tokenId) {
        query = query.eq("token_id", Number.parseInt(tokenId))
      }

      const { data, error } = await query.single()

      if (error) {
        if (error.code === "PGRST116") {
          setError("Ticket not found. Please check the ticket number or token ID.")
        } else {
          throw error
        }
        return
      }

      // Check if the current user is the organizer of this event
      if (data.events.organizer_id !== user.id) {
        setError("You are not authorized to verify tickets for this event.")
        return
      }

      setSearchResult(data)
    } catch (error: any) {
      console.error("Search error:", error)
      setError(error.message || "Failed to search for ticket")
    } finally {
      setIsLoading(false)
    }
  }

  const handleCheckIn = async () => {
    if (!searchResult) return

    const supabase = createClient()
    setIsLoading(true)
    setError(null)

    try {
      const { error } = await supabase
        .from("tickets")
        .update({
          is_used: true,
          used_at: new Date().toISOString(),
        })
        .eq("id", searchResult.id)

      if (error) {
        throw error
      }

      setSearchResult({
        ...searchResult,
        is_used: true,
        used_at: new Date().toISOString(),
      })
    } catch (error: any) {
      console.error("Check-in error:", error)
      setError(error.message || "Failed to check in ticket")
    } finally {
      setIsLoading(false)
    }
  }

  const resetSearch = () => {
    setTicketNumber("")
    setTokenId("")
    setSearchResult(null)
    setError(null)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-gray-900/80 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
              <Ticket className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              NFT Tickets
            </span>
          </Link>
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost">Dashboard</Button>
            </Link>
            <form action="/auth/signout" method="post">
              <Button variant="ghost" type="submit">
                Sign Out
              </Button>
            </form>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Page Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              Ticket Verification
            </h1>
            <p className="text-gray-600 dark:text-gray-300">
              Verify and check-in attendees using their NFT ticket numbers or token IDs
            </p>
          </div>

          {/* Search Form */}
          <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm dark:bg-gray-900/80 mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Search className="w-5 h-5 mr-2" />
                Search Ticket
              </CardTitle>
              <CardDescription>Enter either the ticket number or token ID to verify</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSearch} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="ticketNumber">Ticket Number</Label>
                    <Input
                      id="ticketNumber"
                      type="number"
                      value={ticketNumber}
                      onChange={(e) => {
                        setTicketNumber(e.target.value)
                        if (e.target.value) setTokenId("")
                      }}
                      placeholder="e.g., 123456"
                      disabled={!!tokenId}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tokenId">Token ID</Label>
                    <Input
                      id="tokenId"
                      type="number"
                      value={tokenId}
                      onChange={(e) => {
                        setTokenId(e.target.value)
                        if (e.target.value) setTicketNumber("")
                      }}
                      placeholder="e.g., 789012"
                      disabled={!!ticketNumber}
                    />
                  </div>
                </div>

                {error && (
                  <div className="p-3 text-sm text-red-600 bg-red-50 dark:bg-red-900/20 dark:text-red-400 rounded-lg">
                    {error}
                  </div>
                )}

                <div className="flex space-x-3">
                  <Button
                    type="submit"
                    className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                    disabled={isLoading || (!ticketNumber && !tokenId)}
                  >
                    {isLoading ? "Searching..." : "Search Ticket"}
                  </Button>
                  <Button type="button" variant="outline" onClick={resetSearch}>
                    Reset
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Search Result */}
          {searchResult && (
            <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center">
                    <Ticket className="w-5 h-5 mr-2" />
                    Ticket Details
                  </span>
                  {searchResult.is_used ? (
                    <Badge className="bg-gray-500 text-white flex items-center space-x-1">
                      <CheckCircle className="w-3 h-3" />
                      <span>Used</span>
                    </Badge>
                  ) : (
                    <Badge className="bg-green-500 text-white flex items-center space-x-1">
                      <XCircle className="w-3 h-3" />
                      <span>Valid</span>
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Ticket Info */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg">Ticket Information</h3>
                    <div className="space-y-3">
                      <div className="flex items-center">
                        <Hash className="w-4 h-4 mr-2 text-purple-600" />
                        <span className="text-sm text-gray-600 dark:text-gray-400 mr-2">Ticket #:</span>
                        <span className="font-mono font-bold">{searchResult.ticket_number}</span>
                      </div>
                      <div className="flex items-center">
                        <Hash className="w-4 h-4 mr-2 text-blue-600" />
                        <span className="text-sm text-gray-600 dark:text-gray-400 mr-2">Token ID:</span>
                        <span className="font-mono">{searchResult.token_id}</span>
                      </div>
                      {searchResult.used_at && (
                        <div className="flex items-center">
                          <CheckCircle className="w-4 h-4 mr-2 text-green-600" />
                          <span className="text-sm text-gray-600 dark:text-gray-400 mr-2">Used at:</span>
                          <span>{format(new Date(searchResult.used_at), "PPP p")}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg">Event Information</h3>
                    <div className="space-y-3">
                      <div className="flex items-center">
                        <Ticket className="w-4 h-4 mr-2 text-purple-600" />
                        <span className="text-sm text-gray-600 dark:text-gray-400 mr-2">Event:</span>
                        <span className="font-medium">{searchResult.events.title}</span>
                      </div>
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 mr-2 text-blue-600" />
                        <span className="text-sm text-gray-600 dark:text-gray-400 mr-2">Venue:</span>
                        <span>{searchResult.events.venue}</span>
                      </div>
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-2 text-indigo-600" />
                        <span className="text-sm text-gray-600 dark:text-gray-400 mr-2">Date:</span>
                        <span>{format(new Date(searchResult.events.event_date), "PPP p")}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Attendee Info */}
                <div className="border-t pt-6">
                  <h3 className="font-semibold text-lg mb-4">Attendee Information</h3>
                  <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center">
                        <User className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="font-medium">{searchResult.profiles.full_name}</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{searchResult.profiles.email}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="border-t pt-6">
                  {searchResult.is_used ? (
                    <div className="text-center">
                      <div className="inline-flex items-center space-x-2 text-gray-600 dark:text-gray-400">
                        <CheckCircle className="w-5 h-5" />
                        <span>This ticket has already been used</span>
                      </div>
                    </div>
                  ) : (
                    <Button
                      onClick={handleCheckIn}
                      disabled={isLoading}
                      className="w-full h-12 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                    >
                      {isLoading ? "Checking In..." : "Check In Attendee"}
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
