"use client"

import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Copy, ExternalLink } from "lucide-react"
import { format } from "date-fns"

interface NFTMetadataModalProps {
  isOpen: boolean
  onClose: () => void
  ticket: {
    id: string
    token_id: number
    ticket_number: number
    purchase_price: number
    is_used: boolean
    created_at: string
    transaction_hash: string
    nft_metadata: any
    events: {
      title: string
      venue: string
      event_date: string
    }
  }
}

export default function NFTMetadataModal({ isOpen, onClose, ticket }: NFTMetadataModalProps) {
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const metadata = ticket.nft_metadata || {}

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <span>NFT Metadata</span>
            <Badge>#{ticket.ticket_number}</Badge>
          </DialogTitle>
          <DialogDescription>Detailed information about your NFT ticket</DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* NFT Preview */}
          <div className="text-center">
            <div className="w-48 h-72 mx-auto bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-600 rounded-lg flex items-center justify-center text-white shadow-lg">
              <div className="text-center">
                <div className="text-3xl font-bold mb-2">#{ticket.ticket_number}</div>
                <div className="text-sm opacity-90">NFT Ticket</div>
                <div className="text-xs opacity-75 mt-2">{ticket.events.title}</div>
              </div>
            </div>
          </div>

          {/* Basic Info */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h3 className="font-semibold mb-2">Token Information</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Token ID:</span>
                  <span className="font-mono">{ticket.token_id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Ticket Number:</span>
                  <span className="font-mono">#{ticket.ticket_number}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Purchase Price:</span>
                  <span>${ticket.purchase_price}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Minted:</span>
                  <span>{format(new Date(ticket.created_at), "PPP")}</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-2">Event Information</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Event:</span>
                  <span className="text-right max-w-32 truncate">{ticket.events.title}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Venue:</span>
                  <span className="text-right max-w-32 truncate">{ticket.events.venue}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Date:</span>
                  <span>{format(new Date(ticket.events.event_date), "MMM d, yyyy")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Status:</span>
                  <Badge variant={ticket.is_used ? "secondary" : "default"}>{ticket.is_used ? "Used" : "Active"}</Badge>
                </div>
              </div>
            </div>
          </div>

          {/* Attributes */}
          {metadata.attributes && metadata.attributes.length > 0 && (
            <div>
              <h3 className="font-semibold mb-3">Attributes</h3>
              <div className="grid grid-cols-2 gap-3">
                {metadata.attributes.map((attr: any, index: number) => (
                  <div key={index} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div className="text-sm text-gray-600 dark:text-gray-400">{attr.trait_type}</div>
                    <div className="font-medium">{attr.value}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Transaction Hash */}
          {ticket.transaction_hash && (
            <div>
              <h3 className="font-semibold mb-2">Blockchain Information</h3>
              <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Transaction Hash</div>
                    <div className="font-mono text-sm truncate max-w-64">{ticket.transaction_hash}</div>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" onClick={() => copyToClipboard(ticket.transaction_hash)}>
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(`https://etherscan.io/tx/${ticket.transaction_hash}`, "_blank")}
                    >
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Raw Metadata */}
          <div>
            <h3 className="font-semibold mb-2">Raw Metadata</h3>
            <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <pre className="text-xs overflow-x-auto">{JSON.stringify(metadata, null, 2)}</pre>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
