"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, MapPin, Hash, ExternalLink, Share2, Download } from "lucide-react"
import { format } from "date-fns"
import { useState } from "react"
import NFTMetadataModal from "./nft-metadata-modal"
import Link from "next/link"

interface NFTTicketCardProps {
  ticket: {
    id: string
    token_id: number
    ticket_number: number
    purchase_price: number
    is_used: boolean
    used_at: string | null
    created_at: string
    transaction_hash: string
    nft_metadata: any
    events: {
      id: string
      title: string
      description: string
      venue: string
      event_date: string
      image_url: string | null
      profiles: {
        full_name: string
      }
    }
  }
}

export default function NFTTicketCard({ ticket }: NFTTicketCardProps) {
  const [showMetadata, setShowMetadata] = useState(false)
  const eventDate = new Date(ticket.events.event_date)
  const isEventPassed = eventDate < new Date()

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `NFT Ticket - ${ticket.events.title}`,
          text: `Check out my NFT ticket for ${ticket.events.title}!`,
          url: window.location.href,
        })
      } catch (error) {
        console.log("Error sharing:", error)
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href)
    }
  }

  const downloadNFT = () => {
    // In a real implementation, this would generate and download the NFT image
    const canvas = document.createElement("canvas")
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = 400
    canvas.height = 600

    // Create gradient background
    const gradient = ctx.createLinearGradient(0, 0, 400, 600)
    gradient.addColorStop(0, "#8B5CF6")
    gradient.addColorStop(1, "#3B82F6")
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, 400, 600)

    // Add text
    ctx.fillStyle = "white"
    ctx.font = "bold 24px Arial"
    ctx.textAlign = "center"
    ctx.fillText(ticket.events.title, 200, 100)

    ctx.font = "16px Arial"
    ctx.fillText(`Ticket #${ticket.ticket_number}`, 200, 150)
    ctx.fillText(ticket.events.venue, 200, 200)
    ctx.fillText(format(eventDate, "PPP"), 200, 250)

    // Download
    const link = document.createElement("a")
    link.download = `nft-ticket-${ticket.ticket_number}.png`
    link.href = canvas.toDataURL()
    link.click()
  }

  return (
    <>
      <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80 hover:shadow-xl transition-all duration-300 overflow-hidden group">
        {/* NFT Image */}
        <div className="relative">
          <div className="w-full h-48 bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-600 flex items-center justify-center">
            <div className="text-center text-white">
              <div className="text-4xl font-bold mb-2">#{ticket.ticket_number}</div>
              <div className="text-sm opacity-90">NFT Ticket</div>
            </div>
          </div>
          <div className="absolute top-4 right-4 flex space-x-2">
            {ticket.is_used ? (
              <Badge className="bg-gray-500 text-white">Used</Badge>
            ) : isEventPassed ? (
              <Badge className="bg-orange-500 text-white">Expired</Badge>
            ) : (
              <Badge className="bg-green-500 text-white">Active</Badge>
            )}
          </div>
          <div className="absolute bottom-4 left-4">
            <Badge className="bg-white/90 text-gray-900 backdrop-blur-sm">${ticket.purchase_price}</Badge>
          </div>
        </div>

        <CardHeader className="pb-3">
          <CardTitle className="text-lg line-clamp-2">{ticket.events.title}</CardTitle>
          <CardDescription className="line-clamp-1">
            by {ticket.events.profiles?.full_name || "Unknown Organizer"}
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-3">
          <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
            <Calendar className="w-4 h-4 mr-2" />
            {format(eventDate, "PPP p")}
          </div>

          <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
            <MapPin className="w-4 h-4 mr-2" />
            {ticket.events.venue}
          </div>

          <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
            <Hash className="w-4 h-4 mr-2" />
            Token ID: {ticket.token_id}
          </div>

          {ticket.used_at && (
            <div className="text-sm text-gray-600 dark:text-gray-400">
              Used on {format(new Date(ticket.used_at), "PPP")}
            </div>
          )}

          <div className="pt-4 space-y-2">
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                className="flex-1 bg-transparent"
                onClick={() => setShowMetadata(true)}
              >
                <ExternalLink className="w-4 h-4 mr-1" />
                Metadata
              </Button>
              <Button variant="outline" size="sm" onClick={handleShare}>
                <Share2 className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={downloadNFT}>
                <Download className="w-4 h-4" />
              </Button>
            </div>

            {!ticket.is_used && !isEventPassed && (
              <Link href={`/dashboard/sell-ticket?ticketId=${ticket.id}`}>
                <Button variant="outline" size="sm" className="w-full bg-transparent">
                  List for Sale
                </Button>
              </Link>
            )}

            {ticket.transaction_hash && (
              <Button
                variant="outline"
                size="sm"
                className="w-full text-xs bg-transparent"
                onClick={() => window.open(`https://etherscan.io/tx/${ticket.transaction_hash}`, "_blank")}
              >
                View on Blockchain
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <NFTMetadataModal isOpen={showMetadata} onClose={() => setShowMetadata(false)} ticket={ticket} />
    </>
  )
}
