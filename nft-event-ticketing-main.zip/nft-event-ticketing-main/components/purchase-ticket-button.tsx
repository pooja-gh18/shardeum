"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"

interface PurchaseTicketButtonProps {
  eventId: string
  price: number
  availableTickets: number
}

export default function PurchaseTicketButton({ eventId, price, availableTickets }: PurchaseTicketButtonProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  const handlePurchase = async () => {
    const supabase = createClient()
    setIsLoading(true)
    setError(null)

    try {
      // Check if user is authenticated
      const {
        data: { user },
        error: authError,
      } = await supabase.auth.getUser()

      if (authError || !user) {
        router.push("/auth/login")
        return
      }

      // For now, we'll simulate the NFT minting process
      // In a real implementation, this would interact with a smart contract
      const ticketNumber = Math.floor(Math.random() * 1000000)
      const tokenId = Math.floor(Math.random() * 1000000)

      const { error: insertError } = await supabase.from("tickets").insert({
        event_id: eventId,
        owner_id: user.id,
        token_id: tokenId,
        ticket_number: ticketNumber,
        purchase_price: price,
        nft_metadata: {
          name: `Event Ticket #${ticketNumber}`,
          description: "NFT Event Ticket",
          image: `/placeholder.svg?height=400&width=400&query=nft+ticket+${ticketNumber}`,
          attributes: [
            { trait_type: "Event ID", value: eventId },
            { trait_type: "Ticket Number", value: ticketNumber },
            { trait_type: "Purchase Price", value: price },
          ],
        },
        transaction_hash: `0x${Math.random().toString(16).substr(2, 64)}`,
      })

      if (insertError) {
        throw insertError
      }

      // Record the transfer/mint
      await supabase.from("ticket_transfers").insert({
        ticket_id: tokenId, // This would be the actual ticket ID in production
        from_user_id: user.id,
        transfer_type: "mint",
        transfer_price: price,
        status: "completed",
        transaction_hash: `0x${Math.random().toString(16).substr(2, 64)}`,
        completed_at: new Date().toISOString(),
      })

      router.push("/dashboard/tickets")
    } catch (error: any) {
      console.error("Purchase error:", error)
      setError(error.message || "Failed to purchase ticket")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-2">
      <Button
        onClick={handlePurchase}
        disabled={isLoading || availableTickets <= 0}
        className="w-full h-12 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
      >
        {isLoading ? "Minting NFT..." : "Purchase NFT Ticket"}
      </Button>
      {error && <p className="text-sm text-red-600 dark:text-red-400 text-center">{error}</p>}
    </div>
  )
}
