"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, MapPin, User, TrendingUp, TrendingDown } from "lucide-react"
import { format } from "date-fns"
import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"

interface MarketplaceTicketCardProps {
  listing: {
    id: string
    price: number
    created_at: string
    tickets: {
      id: string
      token_id: number
      ticket_number: number
      purchase_price: number
      nft_metadata: any
      events: {
        id: string
        title: string
        description: string
        venue: string
        event_date: string
        image_url: string | null
        profiles: {
          full_name: string
        }
      }
    }
    profiles: {
      full_name: string
    }
  }
}

export default function MarketplaceTicketCard({ listing }: MarketplaceTicketCardProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  const eventDate = new Date(listing.tickets.events.event_date)
  const isEventPassed = eventDate < new Date()
  const originalPrice = listing.tickets.purchase_price
  const currentPrice = listing.price
  const priceChange = ((currentPrice - originalPrice) / originalPrice) * 100

  const handlePurchase = async () => {
    const supabase = createClient()
    setIsLoading(true)
    setError(null)

    try {
      // Check if user is authenticated
      const {
        data: { user },
        error: authError,
      } = await supabase.auth.getUser()

      if (authError || !user) {
        router.push("/auth/login")
        return
      }

      // Start a transaction to transfer the ticket
      const { error: transferError } = await supabase.from("ticket_transfers").insert({
        ticket_id: listing.tickets.id,
        from_user_id: listing.seller_id,
        to_user_id: user.id,
        transfer_price: listing.price,
        transfer_type: "sale",
        status: "completed",
        transaction_hash: `0x${Math.random().toString(16).substr(2, 64)}`,
        completed_at: new Date().toISOString(),
      })

      if (transferError) {
        throw transferError
      }

      // Update ticket ownership
      const { error: updateError } = await supabase
        .from("tickets")
        .update({
          owner_id: user.id,
          is_transferred: true,
        })
        .eq("id", listing.tickets.id)

      if (updateError) {
        throw updateError
      }

      // Deactivate the listing
      const { error: listingError } = await supabase
        .from("marketplace_listings")
        .update({ is_active: false })
        .eq("id", listing.id)

      if (listingError) {
        throw listingError
      }

      router.push("/dashboard/tickets")
    } catch (error: any) {
      console.error("Purchase error:", error)
      setError(error.message || "Failed to purchase ticket")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm dark:bg-gray-900/80 hover:shadow-xl transition-all duration-300 overflow-hidden group">
      {/* Ticket Preview */}
      <div className="relative">
        <div className="w-full h-48 bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-600 flex items-center justify-center">
          <div className="text-center text-white">
            <div className="text-4xl font-bold mb-2">#{listing.tickets.ticket_number}</div>
            <div className="text-sm opacity-90">NFT Ticket</div>
          </div>
        </div>
        <div className="absolute top-4 right-4 flex space-x-2">
          <Badge className="bg-white/90 text-gray-900 backdrop-blur-sm">${listing.price}</Badge>
        </div>
        <div className="absolute bottom-4 left-4">
          {priceChange > 0 ? (
            <Badge className="bg-green-500 text-white flex items-center space-x-1">
              <TrendingUp className="w-3 h-3" />
              <span>+{priceChange.toFixed(1)}%</span>
            </Badge>
          ) : priceChange < 0 ? (
            <Badge className="bg-red-500 text-white flex items-center space-x-1">
              <TrendingDown className="w-3 h-3" />
              <span>{priceChange.toFixed(1)}%</span>
            </Badge>
          ) : (
            <Badge className="bg-gray-500 text-white">Same Price</Badge>
          )}
        </div>
      </div>

      <CardHeader className="pb-3">
        <CardTitle className="text-lg line-clamp-2">{listing.tickets.events.title}</CardTitle>
        <CardDescription className="line-clamp-1">
          Listed by {listing.profiles?.full_name || "Unknown User"}
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-3">
        <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
          <Calendar className="w-4 h-4 mr-2" />
          {format(eventDate, "PPP p")}
        </div>

        <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
          <MapPin className="w-4 h-4 mr-2" />
          {listing.tickets.events.venue}
        </div>

        <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
          <User className="w-4 h-4 mr-2" />
          Organized by {listing.tickets.events.profiles?.full_name || "Unknown"}
        </div>

        <div className="pt-4 space-y-3">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400">Original Price</p>
              <p className="text-lg font-bold">${originalPrice}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600 dark:text-gray-400">Current Price</p>
              <p className="text-2xl font-bold text-purple-600">${currentPrice}</p>
            </div>
          </div>

          {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}

          {isEventPassed ? (
            <Button disabled className="w-full">
              Event Has Passed
            </Button>
          ) : (
            <Button
              onClick={handlePurchase}
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              {isLoading ? "Processing..." : "Buy Now"}
            </Button>
          )}

          <p className="text-xs text-gray-500 dark:text-gray-400 text-center">
            Listed {format(new Date(listing.created_at), "MMM d, yyyy")}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
